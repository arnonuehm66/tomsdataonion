#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <openssl/aes.h>
#include <openssl/rand.h>

//#include "c_dynamic_arrays.h"
//#include "c_string.h"


//******************************************************************************
long int getSizeOfFile(FILE* hFile) {
  long int liSize = 0;

  fseek(hFile, 0, SEEK_END);
  liSize = ftell(hFile);
  fseek(hFile, 0, SEEK_SET);

  return liSize;
}

//******************************************************************************
//* 1 element = OK, 0 elements = EOF
int readBytes(void* pvBytes, int iLength, FILE* hFile) {
  size_t sBytesRead = 0;
  sBytesRead = fread(pvBytes, iLength, 1, hFile);
  return sBytesRead;
}

//******************************************************************************
void printPayload(uint8_t* pucBytes, int iLength) {
  for (int i = 0; i < iLength; ++i)
    printf("%c", pucBytes[i]);
}


//******************************************************************************
int main(int argc, char* argv[]) {
  FILE*    hFile        = NULL;

  uint8_t  ui8KEK[32]   = {0};
  uint8_t  ui8KEK_IV[8] = {0};

  uint8_t  ui8EK[40]    = {0};
  uint8_t  ui8EK_IV[16] = {0};

  uint8_t* pui8Data     = NULL;
  uint16_t ui16DataLen  = 0;

  uint8_t* pui8Buff     = NULL;

  AES_KEY  aesKEK       = {0};
  AES_KEY  aesEK        = {0};

  // Helper for the padded data to decrypt.
//  uint16_t     ui16ToPad = 0;
//  t_array_byte dabData   = {0};

  if (! (hFile = fopen(argv[1], "rb"))) {
    perror("couldn't open file");
    return 1;
  }

  ui16DataLen = getSizeOfFile(hFile) - 32 - 8 - 40 - 16;
  pui8Data    = (uint8_t*) malloc(ui16DataLen);
  pui8Buff    = (uint8_t*) malloc(ui16DataLen);

  // First 32 bytes: The 256-bit key encrypting key (KEK).
  if (! readBytes(ui8KEK, 32, hFile)) return 1;
  // Next 8 bytes: The 64-bit initialization vector (IV) for the wrapped key.
  if (! readBytes(ui8KEK_IV, 8, hFile)) return 2;

  // Next 40 bytes: The wrapped (encrypted) key. When decrypted, this will become the 256-bit encryption key.
  if (! readBytes(ui8EK, 40, hFile)) return 3;
  // Next 16 bytes: The 128-bit initialization vector (IV) for the encrypted payload.
  if (! readBytes(ui8EK_IV, 16, hFile)) return 4;

  // All remaining bytes: The encrypted payload.
  if (! readBytes(pui8Data, ui16DataLen, hFile)) return 5;

  // Decrypt data's AES key.
  AES_set_decrypt_key(ui8KEK, 256, &aesKEK);
  AES_unwrap_key(&aesKEK, ui8KEK_IV, pui8Buff, ui8EK, 40);

  // Buffer swap to payload encryption key.
  for (int i =0; i < 40; ++i) ui8EK[i] = pui8Buff[i];

  // Copy and pad data to decrypt.
//  dabInit(&dabData);
//  for (uint16_t i = 0; i < ui16DataLen; ++i) dabAdd(&dabData, pui8Data[i]);
//  ui16ToPad = (AES_BLOCK_SIZE - (dabData.sCount % AES_BLOCK_SIZE));
//  for (uint16_t i = 0; i < ui16ToPad;   ++i) dabAdd(&dabData, 0);

  // Decrypt the payload.
  AES_set_decrypt_key(ui8EK, 256, &aesEK);
  AES_cbc_encrypt(pui8Data, pui8Buff, ui16DataLen, &aesEK, ui8EK_IV, AES_DECRYPT);
//  AES_cbc_encrypt(dabData.pBytes, pui8Buff, dabData.sCount, &aesEK, ui8EK_IV, AES_DECRYPT);

  printPayload(pui8Buff, ui16DataLen);

//  dabFree(&dabData);
  free(pui8Data);
  free(pui8Buff);

  fclose(hFile);
}
