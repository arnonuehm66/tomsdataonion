#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// AES-256 CBC

// Enable both ECB and CBC mode. Note this can be done before including aes.h or at compile-time.
// E.g. with GCC by using the -D flag: gcc -c aes.c -DCBC=0 -DECB=1
#define CBC 1
#define ECB 0
#include "aes_hc.h"


//******************************************************************************
// #ifdef AES256
static void decrypt_cbc(void) {
  uint8_t key[] = {
    0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae,
    0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61,
    0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4
  };
  uint8_t in[] = {
    0xf5, 0x8c, 0x4c, 0x04, 0xd6, 0xe5, 0xf1, 0xba, 0x77, 0x9e, 0xab,
    0xfb, 0x5f, 0x7b, 0xfb, 0xd6, 0x9c, 0xfc, 0x4e, 0x96, 0x7e, 0xdb,
    0x80, 0x8d, 0x67, 0x9f, 0x77, 0x7b, 0xc6, 0x70, 0x2c, 0x7d, 0x39,
    0xf2, 0x33, 0x69, 0xa9, 0xd9, 0xba, 0xcf, 0xa5, 0x30, 0xe2, 0x63,
    0x04, 0x23, 0x14, 0x61, 0xb2, 0xeb, 0x05, 0xe2, 0xc3, 0x9b, 0xe9,
    0xfc, 0xda, 0x6c, 0x19, 0x07, 0x8c, 0x6a, 0x9d, 0x1b
  };
  uint8_t  iv[]  = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a,
    0x0b, 0x0c, 0x0d, 0x0e, 0x0f
  };
  uint8_t out[]  = {
    0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e,
    0x11, 0x73, 0x93, 0x17, 0x2a, 0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03,
    0xac, 0x9c, 0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51, 0x30,
    0xc8, 0x1c, 0x46, 0xa3, 0x5c, 0xe4, 0x11, 0xe5, 0xfb, 0xc1, 0x19,
    0x1a, 0x0a, 0x52, 0xef, 0xf6, 0x9f, 0x24, 0x45, 0xdf, 0x4f, 0x9b,
    0x17, 0xad, 0x2b, 0x41, 0x7b, 0xe6, 0x6c, 0x37, 0x10
  };
  uint8_t buffer[64] = {0};

  AES_CBC_decrypt_buffer(buffer, in, 64, key, iv);

  printf("CBC decrypt: ");

  if(0 == memcmp((char*) out, (char*) buffer, 64)) {
    printf("SUCCESS!\n");
  }
  else {
    printf("FAILURE!\n");
  }
}

//******************************************************************************
int readBytes(void* pvBytes, int iLength, FILE* hFile) {
  size_t sBytesRead = 0;

  sBytesRead = fread(pvBytes, iLength, 1, hFile);

  // 1 element  =  OK
  // 0 elements = EOF
  return sBytesRead;
}

//******************************************************************************
void printPayload(uint8_t* pucBytes, int iLength) {
  for (int i = 0; i < iLength; ++i)
    printf("%c", pucBytes[i]);
}

//******************************************************************************
uint16_t getSizeOfFile(FILE* hFile) {
  uint16_t ui16Size = 0;

  fseek(hFile, 0, SEEK_END);
  ui16Size = ftell(hFile);
  fseek(hFile, 0, SEEK_SET);

  return 0;
}

//******************************************************************************
int main(int argc, char* argv[]) {
  FILE*    hFile        = NULL;
  uint8_t  ui8KEK[32]   = {0};
  uint8_t  ui8KEK_IV[8] = {0};
  uint8_t  ui8EK[40]    = {0};
  uint8_t  ui8EK_IV[16] = {0};
  uint8_t* pui8Data     = NULL;
  uint16_t ui16DataLen  = 0;

  if (! (hFile = fopen(argv[1], "rb"))) {
    perror("couldn't open file");
    return 1;
  }

  ui16DataLen = getSizeOfFile(hFile) - 32 - 8 - 40 - 16;
  pui8Data    = (uint8_t*) malloc(ui16DataLen);

  // First 32 bytes: The 256-bit key encrypting key (KEK).
  if (! readBytes(ui8KEK, sizeof(ui8KEK), hFile)) return 1;

  // Next 8 bytes: The 64-bit initialization vector (IV) for the wrapped key.
  if (! readBytes(ui8KEK_IV, sizeof(ui8KEK_IV), hFile)) return 2;

  // Next 40 bytes: The wrapped (encrypted) key. When decrypted, this will become the 256-bit encryption key.
  if (! readBytes(ui8EK, sizeof(ui8EK), hFile)) return 3;

  // Next 16 bytes: The 128-bit initialization vector (IV) for the encrypted payload.
  if (! readBytes(ui8EK_IV, sizeof(ui8EK_IV), hFile)) return 4;

  // All remaining bytes: The encrypted payload.
  if (! readBytes(pui8Data, ui16DataLen, hFile)) return 5;


  // Decrypt data's AES key.
  ;

  // .
  ;


  printPayload(pui8Data, ui16DataLen);

  fclose(hFile);
}
