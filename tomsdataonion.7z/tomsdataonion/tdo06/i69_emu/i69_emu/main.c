#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "c_dynamic_arrays.h"
#include "c_string.h"

#define F_ZERO  0x01
#define F_CARRY 0x10

typedef struct s_cpu {
  int8_t  a;
  int8_t  b;
  int8_t  c;
  int8_t  d;
  int8_t  e;
  int8_t  f;      // 000c 000z
  int32_t la;
  int32_t lb;
  int32_t lc;
  int32_t ld;
  int32_t ptr;
  int32_t pc;
  int32_t ptr_c;
  int8_t  memory[4096]; // Payload size 3262
} t_cpu;

t_cpu g_i69;


//******************************************************************************
uint16_t getSizeOfFile(FILE* hFile) {
  uint16_t ui16Size = 0;

  fseek(hFile, 0, SEEK_END);
  ui16Size = ftell(hFile);
  fseek(hFile, 0, SEEK_SET);

  return ui16Size;
}

//******************************************************************************
//* 1 element = OK, 0 elements = EOF
int readBytes(void* pvBytes, int iLength, FILE* hFile) {
  size_t sBytesRead = 0;
  sBytesRead = fread(pvBytes, iLength, 1, hFile);
  return sBytesRead;
}

//******************************************************************************
void printPayload(uint8_t* pucBytes, int iLength) {
  for (int i = 0; i < iLength; ++i)
    printf("%c", pucBytes[i]);
}

//******************************************************************************
void initCpu(void) {
  g_i69.a     = 0;
  g_i69.b     = 0;
  g_i69.c     = 0;
  g_i69.d     = 0;
  g_i69.e     = 0;
  g_i69.f     = 0;
  g_i69.la    = 0;
  g_i69.lb    = 0;
  g_i69.lc    = 0;
  g_i69.ld    = 0;
  g_i69.ptr   = 0;
  g_i69.pc    = 0;
  g_i69.ptr_c = 0;
  for (int i = 0; i < 4096; ++i) g_i69.memory[i] = 0;
}

//******************************************************************************
int execute(uint8_t* pui8Code) {
  uint8_t  imm8        = 0;
  uint32_t imm32       = 0;
  uint8_t  instruction = pui8Code[g_i69.pc];

  switch(instruction) {
    // ADD a <- b
    case 0xC2 :
      g_i69.f   = 0;
      g_i69.a  += g_i69.b;
      g_i69.pc += 1;
      return 1;

    // APTR imm8
    case 0xE1 :
      g_i69.ptr += pui8Code[g_i69.pc + 1];
      g_i69.pc  += 2;
      return 1;

    // CMP
    case 0xC1 :
      g_i69.f   = (g_i69.a == g_i69.b) ? 0x00 : 0x01;
      g_i69.pc += 1;
      return 1;

      // HALT
      case 0x01 :
        return 0;

      // JEZ imm32
      case 0x21 :
        if (g_i69.f == 0x00)
          g_i69.pc  = *((uint32_t*) (&pui8Code[g_i69.pc + 1]));
        else
          g_i69.pc += 5;
        return 1;

        // JNZ imm32
        case 0x22 :
          if (g_i69.f != 0x00)
            g_i69.pc  = *((uint32_t*) (&pui8Code[g_i69.pc + 1]));
          else
            g_i69.pc += 5;
          return 1;

    // Error state
    default :
      return 0;
  }
}

//******************************************************************************
int main(int argc, char* argv[]) {
  FILE*    hFile       = NULL;
  uint8_t* pui8Code    = NULL;
  uint16_t ui16CodeLen = 0;

  if (! (hFile = fopen(argv[1], "rb"))) {
    perror("couldn't open file");
    return 1;
  }

  ui16CodeLen = getSizeOfFile(hFile);
  pui8Code    = (uint8_t*) malloc(ui16CodeLen);

  // Get the i69 code.
  if (! readBytes(pui8Code, 32, hFile)) return 1;

  initCpu();

  while (execute(pui8Code)) ;

  free(pui8Code);

  fclose(hFile);
}
